const user = USER;
RenderBanks(user.banks);
ShowModalEvent();
CloseModalEvent();
CopyEvent();
MouseLeaveEvent();