const USER = {
    banks: [
      
      {
            name: "MB BANK",
            logo: "./images/mbbank.png",
            number: "858882006",
            owner: "MAI SY TIEN"
        },
      
       
       
    ]
};